import { Component } from '@angular/core';

@Component
(

    {

        selector:"product",
        templateUrl:"./product.component.html",
        styleUrls:["./product.component.css"]
    }
)

export class ProductComponent
{

    product_id : number=0;
    quantity : number=0;
    rate : number=0;
    amount: number =0;



    calc_rate()
    {
        this.amount=this.rate*this.quantity;
    }


}