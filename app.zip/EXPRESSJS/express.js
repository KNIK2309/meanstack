express = require('express');
body = require('body-parser');

var app =express();
var arr=[];

var logger = function(request,response,next)
{
    console.log("In logger method");
    next();
}


var showlogin = function(request,response)
{   
    console.log("In show login method");
    response.setHeader('content-type','text/html');
    response.sendFile("login.html",{root:__dirname});
}

var showregister = function(request,response)
{
    response.setHeader('content-type','text/html');
    response.sendFile("register.html",{root:__dirname});
}

var processregister = function(request,response)
{
    response.setHeader('content-type','text/html');
    arr=[request.body.username,request.body.password,request.body.email,request.body.address];
    if(arr!=null)
    {
        response.send("Registration Successfull" +"----Username :----"+request.body.username+"----Password :----"+request.body.password+"----Email :----"+request.body.email+"----Address :----"+request.body.address);
    }
    else
    {
        response.send("Error in adding account");
    }
}

var showlinks = function(request,response)
{
    response.setHeader('content-type','text/html');
    response.sendFile("showform.html",{root:__dirname});

}

var processlogin = function(request,response)
{
    response.setHeader('content-type','text/html');
    if(arr[0]== request.body.username  && arr[1]==request.body.password)
    {
        response.send("Login Success" +"----Username :----"+arr[0]+"----Email :----"+arr[2]+"----Address :----"+arr[3]);
    }
    else
    {
        response.send("Invalid Account");
    }

}

app.use(body.urlencoded({extended:false}));
app.use(logger);
app.get("/",showlinks);
app.get("/login",showlogin);
app.get("/register",showregister);
app.post("/loginprocess",processlogin);
app.post("/registerprocess",processregister);
app.listen(3000);
console.log("Server started with port no : 3000")


