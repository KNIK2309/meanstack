import { items } from './items';
import { Injectable } from "@angular/core";
import { Http,Response } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';

@Injectable()
export class ItemsService{
    baseurl = "assets/items.json";

    constructor(private http:Http){}

    getAllItems():Observable<items[]>{
        return this.http.get(this.baseurl)
        .map((response:Response)=><items[]>response.json());
    }

}