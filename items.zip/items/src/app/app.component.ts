import { Component, OnInit } from '@angular/core';
import { ItemsService } from 'src/items.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'third';

  parr=[{}];

  constructor(private pservice:ItemsService) {}

  ngOnInit() {
    this.pservice.getAllItems().subscribe((r)=>this.parr=r);
  }
}
