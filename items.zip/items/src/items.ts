export class items {
    itemname;
    quantity;
    price;
    description;

}