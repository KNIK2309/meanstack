express = require("express");
bodyparser = require("body-parser");
process = require("./process");

app = express();

var logger = function(req,resp,next){
	next();
}

app.use(bodyparser.urlencoded({extended:false}));
app.use(logger);

app.get("/",function(req,resp){
	resp.sendFile("form.html",{root:__dirname});
});

app.post("/process",function(req,resp){
	result = process.calculatePrice(req.body.id,req.body.name,req.body.quantity);
	resp.send(result);
});

app.listen(2000);