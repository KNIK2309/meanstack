
itemName = ["Santoor","Nirma"];
itemPrice = [20,30];
order=[];
orderid=[];
exports.calculatePrice=function(a,b,c){
	index = itemName.indexOf(b);
	price=itemPrice[index]*c;
	order.push(price)
	orderid.push(a);
	var total = 0;

	for(var i=0;i<order.length;i++)
		total+=orderid[i];

	return total*0.20;
}